// Mobile Navbar Toggle
const menuToggle = document.getElementById("menu-toggle");
const navLinks = document.getElementById("nav-links");

menuToggle.addEventListener("click", () => {
  navLinks.classList.toggle("active");
});

// Contact Form Submission
document.querySelector(".contact-form").addEventListener("submit", function (e) {
  e.preventDefault();
  alert("Thank you for contacting SmartTransit! We'll get back to you soon.");
  this.reset();
});

//tracking 
let map;
let busMarkers = [];

// Dummy bus locations
let busData = [
  { id: 1, lat: 28.6139, lng: 77.2090, route: "25A" }, // Delhi
  { id: 2, lat: 28.7041, lng: 77.1025, route: "14B" }, // Another point
  { id: 3, lat: 28.5355, lng: 77.3910, route: "7C" }   // Noida
];

function initMap() {
  map = new google.maps.Map(document.getElementById("map"), {
    center: { lat: 28.6139, lng: 77.2090 },
    zoom: 11,
  });

  // Add bus markers
  busData.forEach(bus => {
    let marker = new google.maps.Marker({
      position: { lat: bus.lat, lng: bus.lng },
      map,
      title: `Bus ${bus.route}`,
      icon: {
        url: "https://img.icons8.com/color/48/bus.png",
        scaledSize: new google.maps.Size(40, 40),
      }
    });
    busMarkers.push({ id: bus.id, marker });
  });

  // Simulate live movement
  setInterval(updateBusLocations, 5000);
}

function updateBusLocations() {
  busData.forEach(bus => {
    // Random movement simulation
    bus.lat += (Math.random() - 0.5) * 0.01;
    bus.lng += (Math.random() - 0.5) * 0.01;

    let busMarker = busMarkers.find(b => b.id === bus.id);
    if (busMarker) {
      busMarker.marker.setPosition({ lat: bus.lat, lng: bus.lng });
    }
  });
}
